<aside class="control-sidebar control-sidebar-dark">
    
    <div class="control-panel">
      <div class="item">
        <h4>Theme Color : </h4>
        <input type="text" id="theme_color"
              value="{!! $sessions->BTN_BACKGROUND_COLOR !!}"
              class="form-control jscolor" />
      </div>    
    </div>
</aside>