<aside class="control-sidebar control-sidebar-dark">
    
    <div class="control-panel">
      <div class="item">
        <h4>Theme Color : </h4>
        <input type="text" id="theme_color"
              value="<?php echo $sessions->BTN_BACKGROUND_COLOR; ?>"
              class="form-control jscolor" />
      </div>    
    </div>
</aside><?php /**PATH E:\current_project\workana-new\live_streaming\working\live-streaming-laravel\resources\views/admin/layouts/settings.blade.php ENDPATH**/ ?>