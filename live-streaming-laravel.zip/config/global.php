<?php

return [
    'redirectTo' => '/home'
];
