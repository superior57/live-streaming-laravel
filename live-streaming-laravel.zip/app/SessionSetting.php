<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SessionSetting extends Model
{
    //
    protected $table = 'session_settings';
    protected $primaryKey = 'SS_CODE';
}
